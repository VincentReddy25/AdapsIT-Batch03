UI Assignment – Week 1 (Simple Instructions)

Create a form UI using the starter HTML and CSS given to you.


Rules to Follow
	1.	The form must fit completely inside the viewport (no scrolling).
	2.	All colors must come from CSS variables only.
	3.	The background image must cover and fit the entire viewport.
	4.	Layout must be neat, clean, and properly aligned.
	5.	Use attributes of form and limit the number of words inside the form fields.



Font Awesome CDN Link:
<script src="https://kit.fontawesome.com/c9230b84c9.js" crossorigin="anonymous"></script>
